"""Compose animation frames for the design-space tables from the real scene assets (bg + entity cut-outs)."""
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance, ImageOps, ImageChops
import numpy as np, random, math, os

S = '/tmp/claude-0/-home-claude/1d62b557-5a5b-514e-af3c-0b82e2c89840/scratchpad'
U = '/mnt/user-data/uploads/Tellimations/data/study_gen/training_1'
OUT = S + '/new_frames'; os.makedirs(OUT, exist_ok=True)
FONT = S + '/fonts/'
W, H = 1376, 768
BG = Image.open(U + '/hd/scene_1_bg.png').convert('RGBA')
ENT = {e: Image.open(f'{U}/assets/withoutbg-scene_1_{e}.png').convert('RGBA') for e in ['girl', 'boy', 'crab']}
BBOX = {'girl': (880, 131, 1114, 587), 'boy': (632, 349, 850, 688), 'crab': (180, 556, 344, 693)}
ORDER = ['girl', 'boy', 'crab']  # draw order (back to front)
ICON_BURST = Image.open(S + '/svg_frames/t2_12_x0_y0_w1340_h1340.png').convert('RGBA')
ICON_MAGNET_R = Image.open(S + '/svg_frames/t2_11_x0_y0_w2683_h1339.png').convert('RGBA')

def clean(e):
    """Entity layer with halo pixels removed (same rule as the client)."""
    im = ENT[e].copy(); a = np.array(im)
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    halo = (al < 200) & (r > 200) & (g > 200) & (b > 200)
    a[..., 3][halo] = 0
    return Image.fromarray(a)

CL = {e: clean(e) for e in ORDER}

def scene(layers=None, transforms=None):
    """layers: entities to draw (default all); transforms: {entity: function(img)->img} applied before compositing."""
    layers = ORDER if layers is None else layers; transforms = transforms or {}
    out = BG.copy()
    for e in ORDER:
        if e not in layers: continue
        im = CL[e]
        if e in transforms: im = transforms[e](im)
        out.alpha_composite(im)
    return out

def shift(dx, dy):
    return lambda im: ImageChops.offset(im, dx, dy)

def entity_crop(e):
    x0, y0, x1, y1 = BBOX[e]; return CL[e].crop((x0, y0, x1 + 1, y1 + 1)), (x0, y0)

def save(name, frames):
    for i, f in enumerate(frames):
        f.convert('RGB').save(f'{OUT}/{name}_{i}.png')
    print(name)

# ------------------------------------------------------------------ I2 silhouette (girl)
def silhouette():
    def sil(amount, scale=1.0):
        def f(im):
            a = np.array(im); rgb = a[..., :3].astype(float); rgb = rgb * (1 - amount)
            a[..., :3] = rgb.astype(np.uint8); out = Image.fromarray(a)
            if scale != 1.0:
                x0, y0, x1, y1 = BBOX['girl']; cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
                big = out.resize((int(W * scale), int(H * scale)), Image.LANCZOS)
                canvas = Image.new('RGBA', (W, H), (0, 0, 0, 0))
                canvas.alpha_composite(big, (int(cx - cx * scale), int(cy - cy * scale)))
                out = canvas
            return out
        return f
    return [scene(), scene(transforms={'girl': sil(0.55)}), scene(transforms={'girl': sil(1.0, 1.04)})]

# ------------------------------------------------------------------ C2 disintegration (girl)
def disintegration():
    x0, y0, x1, y1 = BBOX['girl']; crop, (ox, oy) = entity_crop('girl')
    rnd = random.Random(5); B = 14
    cw, ch = crop.size; cols = math.ceil(cw / B); rows = math.ceil(ch / B)
    # release time per block: bottom blocks fall first? use random with a top-to-bottom bias
    rel = {}
    for by in range(rows):
        for bx in range(cols):
            rel[(bx, by)] = min(1.0, max(0.0, rnd.random() * 0.8 + 0.2 * (by / rows)))
    frames = []
    for phase in (0.28, 0.62, 0.95):
        base = scene(layers=['boy', 'crab']); layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        for (bx, by), r in rel.items():
            blk = crop.crop((bx * B, by * B, min(cw, (bx + 1) * B), min(ch, (by + 1) * B)))
            if blk.getbbox() is None: continue
            if r >= phase:
                layer.alpha_composite(blk, (ox + bx * B, oy + by * B)); continue
            t = (phase - r)  # time since release, 0..1
            dx = int((rnd.random() - 0.5) * 2 * 60 * t); dy = int(120 * t * t + 30 * t)
            alpha = max(0.0, 1.0 - t * 1.6)
            if alpha <= 0.02: continue
            a = np.array(blk); a[..., 3] = (a[..., 3] * alpha).astype(np.uint8)
            b2 = Image.fromarray(a)
            if t > 0.25:  # shrink into a particle
                s = max(2, int(B * (1 - t * 0.9))); b2 = b2.resize((s, s), Image.NEAREST)
            layer.alpha_composite(b2, (ox + bx * B + dx, oy + by * B + dy))
        base.alpha_composite(layer); frames.append(base)
    return frames

# ------------------------------------------------------------------ S1 peek (boy as the occluder, hinge on the left)
def peek():
    crop, (ox, oy) = entity_crop('boy'); cw, ch = crop.size
    def frame(openness, glow):
        base = scene(layers=['girl', 'crab'])  # what is behind the boy
        if glow > 0:  # soft halo on the exposed area
            g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
            gd.ellipse([ox - 30, oy - 20, ox + cw + 30, oy + ch + 20], fill=(255, 235, 120, int(150 * glow)))
            g = g.filter(ImageFilter.GaussianBlur(40)); base.alpha_composite(g)
        # flap hinged on its left edge: perspective quad (right edge shorter and closer to the hinge)
        sx = max(0.08, 1 - openness); nw = max(10, int(cw * sx)); k = int(ch * 0.14 * openness)
        # Image.transform QUAD maps output box -> input quad; we want output quad from input rect, so build via inverse:
        # easier: draw the flap by resizing to (nw, ch) then apply a vertical taper with MESH: split into strips
        strips = 24; out = Image.new('RGBA', (nw + 2, ch + 2), (0, 0, 0, 0))
        col = crop.resize((nw, ch), Image.LANCZOS)
        for i in range(strips):
            x0 = int(i * nw / strips); x1 = int((i + 1) * nw / strips)
            if x1 <= x0: continue
            frac = (x0 + x1) / 2 / nw; shrink = int(k * frac)
            strip = col.crop((x0, 0, x1, ch)).resize((x1 - x0, max(2, ch - 2 * shrink)), Image.LANCZOS)
            out.alpha_composite(strip, (x0, shrink))
        sh = ImageEnhance.Brightness(out).enhance(1 - 0.5 * openness)
        base.alpha_composite(sh, (ox, oy))
        # shadow cast by the lifted flap on the exposed area
        if openness > 0.5:
            s = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(s)
            sd.polygon([(ox + nw, oy + 10), (ox + nw + 40, oy + 20), (ox + nw + 40, oy + ch - 10), (ox + nw, oy + ch)], fill=(40, 30, 20, 90))
            s = s.filter(ImageFilter.GaussianBlur(8)); base.alpha_composite(s)
        return base
    return [frame(0.6, 0.4), frame(0.86, 1.0), frame(0.3, 0.2)]

# ------------------------------------------------------------------ T2 timelapse (day to night to dawn)
def timelapse():
    full = scene()
    def tint(img, color, alpha, darken=1.0):
        out = ImageEnhance.Brightness(img).enhance(darken)
        ov = Image.new('RGBA', (W, H), color + (int(255 * alpha),)); out = Image.alpha_composite(out, ov); return out
    sunset = tint(full, (255, 150, 90), 0.28, 0.95)
    night = tint(full, (20, 30, 90), 0.55, 0.45)
    d = ImageDraw.Draw(night)
    d.ellipse([1180, 70, 1260, 150], fill=(245, 245, 220, 255))  # moon
    rnd = random.Random(2)
    for _ in range(28):
        x, y = rnd.randint(20, 1350), rnd.randint(20, 260); r = rnd.choice([2, 2, 3])
        d.ellipse([x - r, y - r, x + r, y + r], fill=(255, 255, 240, 230))
    dawn = tint(full, (255, 190, 210), 0.22, 0.9)
    return [sunset, night, dawn]

# ------------------------------------------------------------------ icons
def pixel_icon(img, target_w):
    bb = img.getbbox(); ic = img.crop(bb); return ic.resize((target_w, int(ic.height * target_w / ic.width)), Image.NEAREST)

def magnets():
    """Split the magnet icon image into the red one (left) and the red/blue one (right)."""
    im = ICON_MAGNET_R; bb = im.getbbox(); ic = im.crop(bb); w = ic.width
    left = ic.crop((0, 0, w // 2, ic.height)); right = ic.crop((w // 2, 0, w, ic.height))
    left = left.crop(left.getbbox()); right = right.crop(right.getbbox())
    return left, right

def sparkle(d, x, y, r, col=(255, 230, 90, 255)):
    d.polygon([(x, y - r), (x + r * 0.3, y - r * 0.3), (x + r, y), (x + r * 0.3, y + r * 0.3), (x, y + r), (x - r * 0.3, y + r * 0.3), (x - r, y), (x - r * 0.3, y - r * 0.3)], fill=col)

# ------------------------------------------------------------------ R1 magnetism (girl and boy drawn together, magnets align face to face)
def magnetism():
    mL, mR = magnets(); MW = 96
    mL = mL.resize((MW, int(mL.height * MW / mL.width)), Image.NEAREST); mR = mR.resize((MW, int(mR.height * MW / mR.width)), Image.NEAREST)
    frames = []
    rnd = random.Random(9)
    # per frame: boy dx, girl dx, boy magnet (cx, cy, angle), girl magnet (cx, cy, angle), sparkles
    # angles: 0 = opening up (U); -90 = opening right (boy's), +90 = opening left (girl's)
    spec = [(0, 0, (790, 540, -40), (1000, 330, 140), 0),
            (45, -55, (835, 520, -68), (945, 400, 112), 6),
            (70, -90, (840, 495, -90), (940, 490, 90), 12)]
    for dxb, dxg, (bcx, bcy, ba), (gcx, gcy, ga), nspark in spec:
        fr = scene(transforms={'boy': shift(dxb, 0), 'girl': shift(dxg, 0)})
        b = mL.rotate(ba, expand=True, resample=Image.NEAREST); g = mR.rotate(ga, expand=True, resample=Image.NEAREST)
        d = ImageDraw.Draw(fr)
        for _ in range(nspark):
            x = (bcx + gcx) // 2 + rnd.randint(-40, 40); y = rnd.randint(min(bcy, gcy) - 60, max(bcy, gcy) + 60); r = rnd.randint(9, 16)
            sparkle(d, x, y, r); sparkle(d, x, y, r // 2, (255, 255, 235, 255))
        fr.alpha_composite(b, (bcx - b.width // 2, bcy - b.height // 2)); fr.alpha_composite(g, (gcx - g.width // 2, gcy - g.height // 2))
        frames.append(fr)
    return frames

# ------------------------------------------------------------------ R2 repel (boy and crab meet in the middle, then are pushed apart)
def red_burst(icon, target_w):
    """Pixel burst icon recoloured to red."""
    ic = pixel_icon(icon, target_w); a = np.array(ic).astype(float)
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
    # bright core -> orange-red, darker rim -> deep red
    nr = 200 + 55 * lum; ng = 20 + 120 * lum ** 2; nb = 15 + 40 * lum ** 3
    a[..., 0], a[..., 1], a[..., 2] = nr, ng, nb
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))

def repel():
    cx0, cy0, cx1, cy1 = BBOX['crab']; bx0, by0, bx1, by1 = BBOX['boy']
    gap = bx0 - cx1  # ~288 px between them at rest
    burst = red_burst(ICON_BURST, 170)
    f1 = scene()
    f2 = scene(transforms={'crab': shift(gap // 2 + 6, 0), 'boy': shift(-(gap // 2) + 6, 0)})
    mx = (cx1 + bx0) // 2 + 6; my = 610
    f2.alpha_composite(burst, (mx - burst.width // 2, my - burst.height // 2))
    f3 = scene(transforms={'crab': shift(-70, 0), 'boy': shift(70, 0)})
    return [f1, f2, f3]

# ------------------------------------------------------------------ R3 causal push (crab rushes into the boy)
def causal_push():
    burst = pixel_icon(ICON_BURST, 150)
    cx0, cy0, cx1, cy1 = BBOX['crab']; bx0, by0, bx1, by1 = BBOX['boy']
    gap = bx0 - cx1  # ~288 px
    f1 = scene(transforms={'crab': shift(int(gap * 0.45), 0)})
    d = ImageDraw.Draw(f1)
    for i, y in enumerate([600, 640, 675]):
        x1 = cx0 + int(gap * 0.45) - 10; d.line([(x1 - 90 - 20 * i, y), (x1, y)], fill=(245, 245, 245, 230), width=9)
    f2 = scene(transforms={'crab': shift(gap - 10, 0)})
    f2.alpha_composite(burst, (bx0 - burst.width // 2 + 10, 610 - burst.height // 2))
    def knocked(im):
        x0, y0, x1, y1 = BBOX['boy']; c = im.crop((x0, y0, x1 + 1, y1 + 1)).rotate(-9, resample=Image.BICUBIC, expand=True, center=(0, (y1 - y0)))
        out = Image.new('RGBA', (W, H), (0, 0, 0, 0)); out.alpha_composite(c, (x0 + 18, y0 - 6)); return out
    f3 = scene(transforms={'crab': shift(gap - 40, 0), 'boy': knocked})
    b2 = burst.resize((110, int(burst.height * 110 / burst.width)), Image.NEAREST)
    f3.alpha_composite(b2, (bx0 - 40, 600 - b2.height // 2))
    return [f1, f2, f3]

# ------------------------------------------------------------------ D2 thought bubble (girl): scalloped pixel cloud beside the head, grows like the speech bubble
def thought_bubble():
    P = 5  # pixel size
    def cloud(sc, ndots):
        rx, ry = 21 * sc, 13.5 * sc; bump = 7.2 * sc
        cx, cy = rx + bump + 3, ry + bump + 3
        gw, gh = int(cx + rx + bump + 16 * sc + 4), int(cy + ry + bump + 4)
        fill = Image.new('L', (gw, gh), 0); fd = ImageDraw.Draw(fill)
        fd.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=255)
        n = 9
        for i in range(n):
            ang = 2 * math.pi * i / n + 0.4; r = bump * (1.0 if i % 2 == 0 else 0.82)
            bx = cx + math.cos(ang) * rx * 0.88; by = cy + math.sin(ang) * ry * 0.88
            fd.ellipse([bx - r, by - r, bx + r, by + r], fill=255)
        # trail circles toward the head (to the right, slightly down)
        t1 = (cx + rx + bump + 3.5 * sc, cy + ry * 0.45, 3.2 * sc); t2 = (cx + rx + bump + 10.5 * sc, cy + ry * 0.85, 2.0 * sc)
        for (tx, ty, r) in (t1, t2): fd.ellipse([tx - r, ty - r, tx + r, ty + r], fill=255)
        outline = fill.filter(ImageFilter.MaxFilter(5))  # 2-unit black border
        im = Image.new('RGBA', (gw, gh), (0, 0, 0, 0))
        im.paste((0, 0, 0, 255), (0, 0), outline); im.paste((255, 255, 255, 255), (0, 0), fill)
        d = ImageDraw.Draw(im); dr = 2.2 * sc; sp = 7.2 * sc
        for i in range(ndots):
            dx = cx - (ndots - 1) * sp / 2 + i * sp; dy = cy + 0.5
            d.ellipse([dx - dr, dy - dr, dx + dr, dy + dr], fill=(30, 30, 30, 255))
        return im.resize((gw * P, gh * P), Image.NEAREST), (int((t2[0] + t2[2]) * P), int(t2[1] * P))
    frames = []
    anchor = (940, 205)  # brim of the hat, where the trail points
    for k, (sc, nd) in enumerate([(0.55, 1), (0.8, 2), (1.0, 3)]):
        fr = scene(); b, (ex, ey) = cloud(sc, nd)
        fr.alpha_composite(b, (anchor[0] - ex, anchor[1] - ey)); frames.append(fr)
    return frames

# ------------------------------------------------------------------ D4 interjection (boy, "goed?")
def interjection():
    def burst(word, scale):
        Wb, Hb = 420, 240
        im = Image.new('RGBA', (Wb, Hb), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        cx, cy = Wb // 2, Hb // 2; pts = []; n = 22; rnd = random.Random(4)
        for i in range(n):
            ang = 2 * math.pi * i / n; r = (0.95 if i % 2 == 0 else 0.68) + rnd.uniform(-0.04, 0.04)
            pts.append((cx + math.cos(ang) * r * (Wb / 2 - 6), cy + math.sin(ang) * r * (Hb / 2 - 6)))
        d.polygon(pts, fill=(255, 235, 60, 255), outline=(0, 0, 0, 255))
        d.line(pts + [pts[0]], fill=(0, 0, 0, 255), width=6)
        f = ImageFont.truetype(FONT + 'Inter-Bold.ttf', 74); tw = d.textlength(word, font=f)
        d.text((cx - tw / 2, cy - 44), word, font=f, fill=(0, 0, 0, 255))
        return im.resize((int(Wb * scale), int(Hb * scale)), Image.LANCZOS)
    frames = []
    bx0, by0, bx1, by1 = BBOX['boy']
    for k, sc in enumerate([0.55, 0.85, 1.0]):
        fr = scene(); b = burst('goed?', sc)
        fr.alpha_composite(b, (bx0 - b.width // 2 - 40, by0 - b.height + 40)); frames.append(fr)
    return frames

# ------------------------------------------------------------------ A1 motion lines (girl dashes)
def motion_lines():
    gm = np.array(CL['girl'].split()[-1]) > 128
    def edge(y, side, dx=0):
        xs = np.where(gm[y])[0]
        if len(xs) == 0: return None
        return (xs.max() if side == 'right' else xs.min()) + dx
    cols = [(70, 70, 70, 235), (245, 245, 245, 245), (110, 110, 110, 235), (225, 225, 225, 245), (60, 60, 60, 235), (180, 200, 235, 240)]
    frames = []
    rnd = random.Random(3)
    for k, (dx, L, side) in enumerate([(-22, 110, 'right'), (-48, 190, 'right'), (18, 120, 'left')]):
        fr = scene(transforms={'girl': shift(dx, 0)}); ov = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
        ys = [190, 225, 260, 295, 330, 370, 410, 450, 490, 525, 560, 590]
        for i, y in enumerate(ys):
            x0 = edge(y, side, dx)
            if x0 is None: continue
            taper = 1 - 0.45 * abs((i - (len(ys) - 1) / 2) / ((len(ys) - 1) / 2))  # longest around mid-height
            ln = int(L * taper * rnd.uniform(0.9, 1.1)); th = 10 + (i % 2) * 2; c = cols[i % len(cols)]
            if side == 'right':
                xa = x0 + 16; d.line([(xa, y), (xa + ln, y)], fill=c, width=th); ends = [xa, xa + ln]
            else:
                xa = x0 - 16; d.line([(xa - ln, y), (xa, y)], fill=c, width=th); ends = [xa - ln, xa]
            for xe in ends: d.ellipse([xe - th // 2, y - th // 2, xe + th // 2, y + th // 2], fill=c)
        fr.alpha_composite(ov); frames.append(fr)
    return frames


# ------------------------------------------------------------------ T1 flashback (old film: desaturation, scratches, ink blots)
def flashback():
    full = scene().convert('RGB')
    def desat(img, amount, blur=0, bright=1.0):
        g = ImageOps.grayscale(img).convert('RGB'); out = Image.blend(img, g, amount)
        if blur: out = out.filter(ImageFilter.GaussianBlur(blur))
        if bright != 1.0: out = ImageEnhance.Brightness(out).enhance(bright)
        return out.convert('RGBA')
    def artifacts(img, seed, n_black, n_white, blots):
        d = ImageDraw.Draw(img); rnd = random.Random(seed)
        for _ in range(n_black + n_white):
            col = (0, 0, 0, 235) if _ < n_black else (255, 255, 255, 220)
            x = rnd.randint(60, W - 60); w = rnd.choice([4, 5, 7]); amp = rnd.uniform(0, 6); fq = rnd.uniform(2, 5)
            y0 = rnd.randint(-10, 80); y1 = H - rnd.randint(-10, 80)
            pts = [(x + amp * math.sin(y / H * fq * math.pi), y) for y in range(y0, y1, 6)]
            d.line(pts, fill=col, width=w)
        for (bx, by, br) in blots:  # ink blots: spiky polygon + satellites
            pts = []; n = 26
            for i in range(n):
                ang = 2 * math.pi * i / n; r = br * rnd.uniform(0.62, 1.0)
                pts.append((bx + math.cos(ang) * r, by + math.sin(ang) * r))
            d.polygon(pts, fill=(0, 0, 0, 255))
            for _ in range(5):
                a = rnd.uniform(0, 2 * math.pi); rr = br * rnd.uniform(1.05, 1.5); sr = rnd.uniform(2, 5)
                d.ellipse([bx + math.cos(a) * rr - sr, by + math.sin(a) * rr - sr, bx + math.cos(a) * rr + sr, by + math.sin(a) * rr + sr], fill=(0, 0, 0, 255))
        for _ in range(8):  # dust specks
            x, y = rnd.randint(0, W - 1), rnd.randint(0, H - 1); r = rnd.choice([2, 3, 4])
            d.ellipse([x - r, y - r, x + r, y + r], fill=(0, 0, 0, 200))
        return img
    f1 = desat(full, 0.6)
    f2 = artifacts(desat(full, 1.0, blur=2.2, bright=1.02), 11, 3, 1, [(400, 150, 26), (1010, 640, 18)])
    f3 = artifacts(desat(full, 1.0, blur=2.2, bright=1.10), 23, 3, 2, [(1240, 120, 20), (330, 590, 24)])
    return [f1, f2, f3]

# ------------------------------------------------------------------ C3 missing piece (jigsaw hole at the castle; the piece with the absent seagull hovers at the frame edge)
SEAGULL = Image.open('/mnt/user-data/uploads/Tellimations/data/prolific_gen/study1_C3_A/assets/withoutbg-scene_1_seagull.png').convert('RGBA')
HOLE = (25, 84, 116); EDGE = (150, 190, 225)

def puzzle_mask(body, tabs=('top', 'right', 'bottom'), notches=('left',), ss=2):
    """L mask of a jigsaw piece: square body with round tabs / notches. Canvas = body + 2*tab margin."""
    tr = int(body * 0.17); neck = int(body * 0.19); m = tr + 4
    size = body + 2 * m; B = body * ss; M = m * ss; TR = tr * ss; NK = neck * ss
    im = Image.new('L', (size * ss, size * ss), 0); d = ImageDraw.Draw(im)
    d.rectangle([M, M, M + B, M + B], fill=255)
    c = M + B // 2
    pos = {'top': (c, M - TR * 0.55), 'bottom': (c, M + B + TR * 0.55), 'left': (M - TR * 0.55, c), 'right': (M + B + TR * 0.55, c)}
    for side in tabs:
        x, y = pos[side]
        if side in ('top', 'bottom'): d.rectangle([c - NK // 2, min(y, c), c + NK // 2, max(y, c)], fill=255)
        else: d.rectangle([min(x, c), c - NK // 2, max(x, c), c + NK // 2], fill=255)
        d.ellipse([x - TR, y - TR, x + TR, y + TR], fill=255)
    for side in notches:
        x, y = {'top': (c, M + TR * 0.55), 'bottom': (c, M + B - TR * 0.55), 'left': (M + TR * 0.55, c), 'right': (M + B - TR * 0.55, c)}[side]
        if side in ('top', 'bottom'): d.rectangle([c - NK // 2, min(y, M if side == 'top' else M + B), c + NK // 2, max(y, M if side == 'top' else M + B)], fill=0)
        else: d.rectangle([min(x, M if side == 'left' else M + B), c - NK // 2, max(x, M if side == 'left' else M + B), c + NK // 2], fill=0)
        d.ellipse([x - TR, y - TR, x + TR, y + TR], fill=0)
    return im.resize((size, size), Image.LANCZOS), m

def piece_layer(mask, fill, alpha, edge_alpha, content=None):
    """RGBA layer of a piece: flat fill (+ optional content image centred) and a light edge."""
    w, h = mask.size; im = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    im.paste(fill + (255,), (0, 0), mask)
    if content is not None:
        im.alpha_composite(content, ((w - content.width) // 2, (h - content.height) // 2))
        im.putalpha(ImageChops.multiply(im.split()[-1], mask))
    edge = ImageChops.subtract(mask.filter(ImageFilter.MaxFilter(7)), mask.filter(ImageFilter.MinFilter(3)))
    e = Image.new('RGBA', (w, h), EDGE + (0,)); e.putalpha(edge.point(lambda v: int(v * edge_alpha)))
    a = im.split()[-1].point(lambda v: int(v * alpha)); im.putalpha(a); im.alpha_composite(e)
    return im

def missing_piece():
    hole_mask, hm = puzzle_mask(300)
    hx, hy = 390 - hm, 330 - hm  # body at x 390..690, y 330..630 (the castle)
    def compose(hole_alpha, hole_edge, piece=None):
        out = BG.copy()
        out.alpha_composite(piece_layer(hole_mask, HOLE, hole_alpha, hole_edge), (hx, hy))
        for e in ORDER: out.alpha_composite(CL[e])
        if piece is not None:
            pm, pmm = puzzle_mask(200, tabs=('right', 'bottom'), notches=('top',))
            sg = SEAGULL.crop((1026, 371, 1158, 506)); sg = sg.resize((int(sg.width * 1.1), int(sg.height * 1.1)), Image.LANCZOS)
            px, py, pa = piece
            out.alpha_composite(piece_layer(pm, (120, 170, 210), pa, min(1.0, pa + 0.15), content=sg), (px - pmm, py - pmm))
        return out
    return [compose(0.45, 0.8), compose(1.0, 0.9, (70, 40, 0.55)), compose(1.0, 0.6, (60, 30, 0.9))]

if __name__ == '__main__':
    save('I2_silhouette', silhouette())
    save('C2_disintegration', disintegration())
    save('S1_peek', peek())
    save('T2_timelapse', timelapse())
    save('R1_magnetism', magnetism())
    save('R2_repel', repel())
    save('R3_causal_push', causal_push())
    save('D2_thought_bubble', thought_bubble())
    save('D4_interjection', interjection())
    save('A1_motion_lines', motion_lines())
    save('T1_flashback', flashback())
    save('C3_missing_piece', missing_piece())
    # contact sheet
    names = ['I2_silhouette', 'C2_disintegration', 'S1_peek', 'T2_timelapse', 'R1_magnetism', 'R2_repel', 'R3_causal_push', 'D2_thought_bubble', 'D4_interjection', 'A1_motion_lines', 'T1_flashback', 'C3_missing_piece']
    tw = 380; th = int(768 * tw / 1376)
    sheet = Image.new('RGB', (3 * tw + 230, len(names) * (th + 4)), 'white'); d = ImageDraw.Draw(sheet); f = ImageFont.truetype(FONT + 'Inter-Regular.ttf', 22)
    for r, n in enumerate(names):
        d.text((4, r * (th + 4) + th // 2 - 10), n, font=f, fill='black')
        for c in range(3): sheet.paste(Image.open(f'{OUT}/{n}_{c}.png').resize((tw, th)), (230 + c * tw, r * (th + 4)))
    sheet.save(S + '/new_contact.jpg', quality=82); print(sheet.size)
