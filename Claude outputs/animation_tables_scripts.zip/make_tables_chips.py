from PIL import Image, ImageDraw, ImageFont
import json

S = '/tmp/claude-0/-home-claude/1d62b557-5a5b-514e-af3c-0b82e2c89840/scratchpad'
OLD = S + '/harness/old_frames'; NEW = S + '/new_frames'
FONT = S + '/fonts/'
def font(style, size):
    return ImageFont.truetype(FONT + {'r': 'Inter-Regular.ttf', 'b': 'Inter-Bold.ttf', 'sb': 'Inter-SemiBold.ttf', 'm': 'Inter-Medium.ttf', 'i': 'Inter-Italic.ttf'}[style], size)

DARK = (56, 56, 56); INK = (40, 40, 40); WHITE = (255, 255, 255); BORDER = (142, 142, 142); RULE = (200, 200, 200)
KIND = {
    'purple': {'text': (231, 187, 248), 'tail': (198, 139, 234), 'sub': (241, 220, 250)},
    'blue': {'text': (186, 205, 244), 'tail': (92, 142, 242), 'sub': (202, 218, 249)},
    'salmon': {'text': (248, 190, 180), 'tail': (247, 125, 114), 'sub': (251, 205, 200)},
    'green': {'text': (190, 234, 196), 'tail': (118, 200, 138), 'sub': (212, 240, 218)},
    'pink': {'text': (252, 198, 214), 'tail': (246, 172, 198), 'sub': (253, 228, 236)},
}
CH = 96; R = 24; PAD = 28; SUBPAD = 18; SUBGAP = 14
F_LABEL = font('b', 52); F_SUB = font('b', 44); F_BOX = font('b', 46); F_BOX_S = font('b', 42); F_HEAD = font('b', 58)

def text_w(d, t, f): return d.textlength(t, font=f)

def chip(label, kind, subs=(), sub_font=None, max_tail_w=None):
    """Dark label with colored text, followed by a colored tail holding light sub-chips (wrapped if needed)."""
    sub_font = sub_font or F_SUB
    tmp = ImageDraw.Draw(Image.new('RGB', (10, 10)))
    lw = int(text_w(tmp, label, F_LABEL)) + 2 * PAD
    # layout sub-chips in rows
    rows = [[]]; x = 0
    for s in subs:
        sw = int(text_w(tmp, s, sub_font)) + 2 * SUBPAD
        if max_tail_w and rows[-1] and x + sw + SUBGAP > max_tail_w - 2 * SUBPAD:
            rows.append([]); x = 0
        rows[-1].append((s, sw)); x += sw + SUBGAP
    tail_w = 0
    if subs:
        tail_w = max(sum(sw for _, sw in r) + SUBGAP * (len(r) - 1) for r in rows) + 2 * SUBPAD + R
    h = CH if len(rows) <= 1 or not subs else CH + (len(rows) - 1) * (CH - 2 * SUBPAD + 8)
    im = Image.new('RGBA', (lw + tail_w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if subs:
        d.rounded_rectangle([lw - R, 0, lw + tail_w - 1, h - 1], R, fill=KIND[kind]['tail'])
    d.rounded_rectangle([0, 0, lw - 1, h - 1], R, fill=DARK)
    d.text((PAD, h / 2 - 32), label, font=F_LABEL, fill=KIND[kind]['text'])
    if subs:
        sub_h = CH - 2 * SUBPAD
        yy = SUBPAD
        for r in rows:
            xx = lw + SUBPAD
            for s, sw in r:
                d.rounded_rectangle([xx, yy, xx + sw - 1, yy + sub_h - 1], 16, fill=KIND[kind]['sub'])
                d.text((xx + SUBPAD, yy + sub_h / 2 - 27), s, font=sub_font, fill=INK); xx += sw + SUBGAP
            yy += sub_h + 8
    return im

def wrap(d, text, f, maxw):
    words = text.split(); lines = []; cur = ''
    for w_ in words:
        t = (cur + ' ' + w_).strip()
        if text_w(d, t, f) > maxw and cur: lines.append(cur); cur = w_
        else: cur = t
    if cur: lines.append(cur)
    return lines

def box(text, width, f=F_BOX, min_h=CH):
    """White rounded box with grey border and bold dark text, wrapped to width."""
    tmp = ImageDraw.Draw(Image.new('RGB', (10, 10)))
    lines = wrap(tmp, text, f, width - 2 * PAD)
    lh = f.size + 10; h = max(min_h, len(lines) * lh + 2 * PAD - 10)
    im = Image.new('RGBA', (width, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([2, 2, width - 3, h - 3], R, fill=WHITE, outline=BORDER, width=5)
    y = (h - len(lines) * lh) / 2 + 2
    for ln in lines:
        d.text((PAD, y), ln, font=f, fill=INK); y += lh
    return im

def rounded_frame(img, w, radius=30, border=4):
    h = int(img.height * w / img.width); im = img.convert('RGBA').resize((w, h), Image.LANCZOS)
    m = Image.new('L', (w, h), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], radius, fill=255)
    out = Image.new('RGBA', (w, h), (0, 0, 0, 0)); out.paste(im, (0, 0), m)
    ImageDraw.Draw(out).rounded_rectangle([1, 1, w - 2, h - 2], radius, outline=(0, 0, 0, 255), width=border)
    return out

def load_frame(aid, k):
    """Old frames (already bordered, 1383x772 incl. border) for the untouched animations; new composites otherwise."""
    old = {'I1': 't1_spotlight', 'C1': 't1_sequential_glow', 'A2': 't1_flip', 'P1': 't1_color_pop', 'P2': 't1_emanation', 'S2': 't1_stamp',
           'D1': 't2_speech_bubble', 'D3': 't2_alert'}
    new = {'I2': 'I2_silhouette', 'C2': 'C2_disintegration', 'S1': 'S1_peek', 'T2': 'T2_timelapse', 'R1': 'R1_magnetism', 'R2': 'R2_repel',
           'R3': 'R3_causal_push', 'D2': 'D2_thought_bubble', 'D4': 'D4_interjection', 'A1': 'A1_motion_lines', 'T1': 'T1_flashback', 'C3': 'C3_missing_piece'}
    if aid in old:
        im = Image.open(f'{OLD}/{old[aid]}_{k}.png').convert('RGBA')
        # strip the exported border region: crop 4 px inside then re-border consistently
        return im.crop((16, 16, im.width - 16, im.height - 16))
    return Image.open(f'{NEW}/{new[aid]}_{k}.png').convert('RGBA')

# ------------------------------------------------------------------ content
ROWS = [
 ('I1', 'Identity', 'Who?', 'Spotlight', 'A dog is digging in the sand.', 'A girl is walking on the beach.', ['CH', 'S'],
  'Darkens the scene except the target, which pulses with a soft halo.', ['dimStrength', 'glowStrength', 'maxHaloSize']),
 ('I2', 'Identity', 'Who?', 'Silhouette', 'The mom is carrying a bucket.', 'Someone is walking with a bucket.', ['CH'],
  'Turns the target into a flat black shape, holds, then snaps back.', ['holdMs', 'pulseAmplitude', 'cycles']),
 ('C1', 'Count', 'How many?', 'Sequential Glow', 'The castle has three towers.', 'The sandcastle has towers.', ['CH', 'ENP'],
  'Brightens similar entities one after the other.', ['glowBrightness']),
 ('C2', 'Count', 'How many?', 'Disintegration', 'Two girls are walking on the beach.', 'The crab is next to the tower.', ['CH'],
  'Dissolves an entity into particles.', ['driftAmount', 'fallSpeed']),
 ('C3', 'Count', 'How many?', 'Missing Piece', 'The crab is climbing the tower.', 'The boy is building a castle.', ['CH'],
  'Opens a jigsaw hole where an absent entity would be; the matching piece hovers at the frame edge.', ['holeScale', 'edgePulse', 'pieceOpacity', 'holdMs']),
 ('P1', 'Property', 'What are they like?', 'Color Pop', 'The girl has a red hat.', 'A girl is carrying a bucket.', ['ENP', 'ADV'],
  'Desaturates the scene except the target, so that its attributes stand out.', ['desaturationStrength', 'saturationBoost']),
 ('P2', 'Property', 'What are they like?', 'Emanation', 'The boy is scared of the crab.', 'The boy is building a sandcastle.', ['ENP', 'ADV', 'IR'],
  'Adds particles around the target (hearts, tears, steam, frost, sparkles, anger) that externalize an emotion or a physical property.', ['particleCount', 'tintSaturation']),
 ('A1', 'Action', 'What are they doing?', 'Motion Lines', 'The girl is running to the water.', 'The girl has a bucket.', ['A', 'IE'],
  'Dashes the target back and forth with streaking lines that emphasize direction and speed.', ['lineLength', 'amplitude']),
 ('A2', 'Action', 'What are they doing?', 'Flip', 'The boy is sleeping on the sand.', 'There is a boy next to a castle.', ['A', 'IE'],
  'Mirrors the target horizontally and back.', ['speed']),
 ('S1', 'Space', 'Where?', 'Peek', 'Nothing is hiding behind the sandcastle.', 'The boy is sitting in front of the castle.', ['S'],
  'Lifts an occluding entity like a flap hinged on one edge, exposing what is behind it, then closes back.', ['openness', 'holdMs', 'glowStrength']),
 ('S2', 'Space', 'Where?', 'Stamp', 'The crab is in the water.', 'There is a crab.', ['CH', 'S'],
  'Lifts the target to reveal its black silhouette and snaps it back with radiating cracks.', ['liftPixels', 'crackCount']),
 ('T1', 'Time', 'When?', 'Flashback', 'The girl fills her bucket.', 'The girl is walking with a bucket of water.', ['S', 'T'],
  'Briefly desaturates and re-saturates the scene, like an old film.', ['flickerIntensity', 'scratchCount']),
 ('T2', 'Time', 'When?', 'Timelapse', 'The castle is finished.', 'The boy is building a castle.', ['S', 'T'],
  'Runs a day-to-night cycle over the scene.', ['nightOpacity']),
 ('R1', 'Relation', 'How are they connected?', 'Magnetism', 'The girl does not know the boy.', 'There is a girl and a boy.', ['CC'],
  'Draws two entities together.', ['magnetScale', 'sparkleCount', 'sparkleRadius']),
 ('R2', 'Relation', 'How are they connected?', 'Repel', 'The boy is playing with the crab.', 'The boy and the crab are at the castle.', ['CC'],
  'Pushes two entities apart.', ['repelPixels', 'impactScale']),
 ('R3', 'Relation', 'How are they connected?', 'Causal Push', 'The boy is knocking down the tower.', 'The tower is falling.', ['CC', 'SC', 'IE', 'CO'],
  'Rushes one entity into another with an impact flash.', ['knockPixels', 'impactScale']),
 ('D1', 'Discourse', 'What lies beyond the picture?', 'Speech Bubble', 'The boy is calling the girl.', 'The girl comes back with water.', ['L'],
  'Appears above a character with an ellipsis or a keyword.', ['scale']),
 ('D2', 'Discourse', 'What lies beyond the picture?', 'Thought Bubble', 'The girl wants to go home.', 'The girl carries a bucket.', ['IR', 'P', 'M'],
  'Appears above a character with an ellipsis or a keyword.', ['scale']),
 ('D3', 'Discourse', 'What lies beyond the picture?', 'Alert', 'Nothing is happening at the castle.', 'The boy is building a castle.', ['IE', 'IR'],
  'Places an exclamation mark above an entity to which something important is happening.', ['markCount', 'scale']),
 ('D4', 'Discourse', 'What lies beyond the picture?', 'Interjection', 'The boy goed to the beach.', 'The girl has a bucket.', ['G', 'T', 'ENP', 'ADV', 'SC'],
  "Shows the child's own word in a comic burst: a question mark flags an error, an ellipsis invites elaboration.", ['scale']),
]

# ------------------------------------------------------------------ layout
W = 4800
X_B, W_B = 40, 1000      # example utterances
X_A, W_A = 1080, 960     # animation: name, params, behavior
X_C, W_C = 2080, 440
X_D, FW, FG = 2560, 700, 50
ROW_PAD = 30; GROUP_H = 130; SEP = 3; HEAD_H = 120

def row_image(r):
    aid, cat, q, name, err, opp, misl, behavior, params = r
    tmp = ImageDraw.Draw(Image.new('RGB', (10, 10)))
    # column A: name chip, params chip, behavior box (stacked)
    a = chip(name.lower(), 'purple', [f'id:{aid}', cat], max_tail_w=W_A - int(text_w(tmp, name.lower(), F_LABEL)) - 2 * PAD)
    pc = chip('params', 'blue', params, sub_font=font('b', 38), max_tail_w=W_A - int(text_w(tmp, 'params', F_LABEL)) - 2 * PAD)
    eb = box(behavior, W_A, F_BOX_S, min_h=CH)
    hA = a.height + 14 + pc.height + 14 + eb.height
    # column B: correction / suggestion chips with boxes
    cc = chip('correction', 'salmon'); sc = chip('suggestion', 'green')
    bw = W_B - cc.width - 30
    cb = box(err, bw); sb = box(opp, bw)
    hB = max(cc.height, cb.height) + 20 + max(sc.height, sb.height)
    # column C
    mc = chip('misl', 'blue', misl, max_tail_w=W_C - int(text_w(tmp, 'misl', F_LABEL)) - 2 * PAD)
    # column D
    frames = [rounded_frame(load_frame(aid, k), FW, radius=40, border=5) for k in range(3)]
    h = max(hA, hB, frames[0].height, mc.height) + 2 * ROW_PAD
    im = Image.new('RGBA', (W, h), (255, 255, 255, 255)); d = ImageDraw.Draw(im)
    # A
    y = (h - hA) // 2
    im.alpha_composite(a, (X_A, y)); y += a.height + 14
    im.alpha_composite(pc, (X_A, y)); y += pc.height + 14
    im.alpha_composite(eb, (X_A, y))
    # B
    y = (h - hB) // 2
    for ch_, bx in [(cc, cb), (sc, sb)]:
        rowh = max(ch_.height, bx.height)
        im.alpha_composite(ch_, (X_B, y + (rowh - ch_.height) // 2))
        d.line([(X_B + ch_.width, y + rowh // 2), (X_B + ch_.width + 30, y + rowh // 2)], fill=DARK, width=6)
        im.alpha_composite(bx, (X_B + ch_.width + 30, y + (rowh - bx.height) // 2)); y += rowh + 20
    # C
    im.alpha_composite(mc, (X_C, (h - mc.height) // 2))
    # D
    fy = (h - frames[0].height) // 2
    for k, fr in enumerate(frames): im.alpha_composite(fr, (X_D + k * (FW + FG), fy))
    return im

def group_header(cat, q):
    im = Image.new('RGBA', (W, GROUP_H), (255, 255, 255, 255))
    c = chip(cat, 'pink', [q])
    im.alpha_composite(c, (X_B, (GROUP_H - c.height) // 2 + 10))
    return im

def make_page(ids, out):
    by_id = {r[0]: r for r in ROWS}
    parts = []; prev = None
    for i in ids:
        r = by_id[i]
        if r[1] != prev:
            parts.append(('hdr', group_header(r[1], r[2]))); prev = r[1]
        parts.append(('row', row_image(r)))
    H = sum(p.height for _, p in parts) + 40 + HEAD_H
    page = Image.new('RGB', (W, H), 'white'); y = 20; d = ImageDraw.Draw(page)
    for x, label in [(X_B, 'Example Utterance'), (X_A, 'Animation'), (X_C, 'MISL'), (X_D, 'Frames')]:
        d.text((x + 6, y + 18), label, font=F_HEAD, fill=INK)
    d.line([(X_B, y + HEAD_H - 14), (W - 40, y + HEAD_H - 14)], fill=DARK, width=5)
    y += HEAD_H
    for kind, p in parts:
        page.paste(p, (0, y), p)
        if kind == 'row':
            d.line([(X_B, y + p.height), (W - 40, y + p.height)], fill=RULE, width=SEP)
        y += p.height
    page.save(out); print(out, page.size)
    page.resize((1400, int(H * 1400 / W))).save(out.replace('.png', '_preview.jpg'), quality=82)

make_page(['I1', 'I2', 'C1', 'C2', 'C3', 'P1', 'P2', 'A1', 'A2'], S + '/animations_table_1.png')
make_page(['S1', 'S2', 'T1', 'T2', 'R1', 'R2', 'R3', 'D1', 'D2', 'D3', 'D4'], S + '/animations_table_2.png')
